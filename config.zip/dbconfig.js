module.exports={
    host: '35.194.37.76',
    user: 'pineapple',
    port: 3306,
    password: '1q2w3e',
    database: 'pineapple'
}